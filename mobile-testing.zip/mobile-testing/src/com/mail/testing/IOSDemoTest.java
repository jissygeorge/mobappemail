package com.mail.testing;

import java.net.URL;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.IOSMobileCapabilityType;



public class IOSDemoTest extends BaseTest {
	protected IOSDriver<IOSElement> driver = null;

	@BeforeMethod
	@Parameters("deviceQuery")
	public void setUp(@Optional("@os='ios'") String deviceQuery) throws Exception {
		init(deviceQuery);
		// Init application / device capabilities
		// Launch the pre-installed Apple/IO app for Mail
		// Assumes that the mail app is configured with a valid mailbox
		dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, "com.apple.mobilemail");		
		driver = new IOSDriver<>(new URL(getProperty("url",cloudProperties) + "/wd/hub"), dc);
	}

	@Test
	public void testwithoutSubject() {

		// Click on Compose icon
		driver.findElement(in.Repo.obj("Mailbox.Compose")).click();
		
		// Enter the "To" email id
		driver.findElementByXPath("//*[@accessibilityLabel='toField']").sendKeys("abc@yahoo.com\n");
		
		// Enter the email body
		driver.findElementByXPath("//*[@text='Message body']").sendKeys("testing..");
		
		// Send the email without a subject
		driver.findElementByXPath("//*[@text='Send']").click();
		
		
		// Verify that the popup message is displayed		
		Assert.assertTrue(driver.findElementByXPath("//*[@text='This message has no subject. Do you want to send it anyway?']").isDisplayed());
		
		
		// Close down the message
		
		// Click on Cancel to cancel the message send operation
		driver.findElementByXPath("//*[@text='Cancel' and ./parent::*[@class='UIAView']]").click();
		
		// Click on Cancel to cancel the new message
		driver.findElementByXPath("//*[@text='Cancel']").click();
		
		// Confirm the delete the draft
		driver.findElementByXPath("//*[@text='Delete Draft']").click();
		
		
		
	}

	@Test
	public void testwithSubject() {

		// Click on Compose icon
		driver.findElement(in.Repo.obj("Mailbox.Compose")).click();
		
		// Enter the "To" email id
		driver.findElementByXPath("//*[@accessibilityLabel='toField']").sendKeys("testusertest2468@gmail.com\n");
		
		// Enter the email subject
		driver.findElementByXPath("//*[@text='Subject: ']").sendKeys("testing subject");

		
		// Enter the email body
		driver.findElementByXPath("//*[@text='Message body']").sendKeys("testing..");
		
		// Send the email without a subject
		driver.findElementByXPath("//*[@text='Send']").click();
		

		// Back to folder list
		driver.findElementByXPath("//*[@text='Mailboxes']").click();
		
		// send folder
		driver.findElementByXPath("//*[@text='Sent' and @class='UIAStaticText']").click();
		
		
		//filter for unread
		//driver.findElementByXPath("//*[@text='Filter messages']").click();
		
		//verify the send item
		Assert.assertTrue(driver.findElementByXPath("//*[@text='testusertest2468@gmail.com']").isDisplayed());
		
		
		// Back to folder list
		driver.findElementByXPath("//*[@text='Mailboxes']").click();
		
		
		// back to inbox
		driver.findElementByXPath("//*[@text='Inbox' and @class='UIAStaticText']").click();
		
	}
	
	
	@AfterMethod
	public void tearDown() {

		driver.quit();
	}

}
